import { useState, useEffect, useCallback } from 'react';
import { ApiKey } from '../types';

const STORAGE_KEY = 'genai-api-keys';

export const useApiKeyManager = () => {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [currentIndex, setCurrentIndex] = useState<number>(0);

  useEffect(() => {
    try {
      const storedKeys = localStorage.getItem(STORAGE_KEY);
      if (storedKeys) {
        const parsedKeys = JSON.parse(storedKeys);
        if (Array.isArray(parsedKeys) && parsedKeys.length > 0) {
          setApiKeys(parsedKeys);
        }
      }
    } catch (error) {
      console.error("Failed to parse API keys from localStorage", error);
    }
  }, []);

  const saveKeys = (keys: ApiKey[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(keys));
    setApiKeys(keys);
  };

  const addApiKey = useCallback((key: string) => {
    if (!key.trim()) return;
    const newKey = { id: Date.now().toString(), key };
    const updatedKeys = [...apiKeys, newKey];
    saveKeys(updatedKeys);
    if (apiKeys.length === 0) {
      setCurrentIndex(0);
    }
  }, [apiKeys]);

  const removeApiKey = useCallback((id: string) => {
    const updatedKeys = apiKeys.filter(k => k.id !== id);
    saveKeys(updatedKeys);
    if (currentIndex >= updatedKeys.length && updatedKeys.length > 0) {
      setCurrentIndex(updatedKeys.length - 1);
    } else if (updatedKeys.length === 0) {
        setCurrentIndex(0);
    }
  }, [apiKeys, currentIndex]);

  const currentApiKey = apiKeys.length > 0 ? apiKeys[currentIndex] : null;

  const executeWithRetry = useCallback(async <T,>(
    apiCall: (apiKey: string) => Promise<T>
  ): Promise<T> => {
    if (apiKeys.length === 0) {
      throw new Error("No API Key provided. Please add an API key.");
    }

    let lastError: Error | null = null;
    let localIndex = currentIndex;

    for (let i = 0; i < apiKeys.length; i++) {
        const keyToTry = apiKeys[localIndex];
        if (!keyToTry) {
            localIndex = (localIndex + 1) % apiKeys.length;
            continue;
        }
        
        try {
            const result = await apiCall(keyToTry.key);
            // If success, set the current index to the one that worked
            setCurrentIndex(localIndex);
            return result;
        } catch (e: any) {
            lastError = e;
            const isQuotaError = /quota|limit|429|exhausted|API key not valid/i.test(e.message);
            if (isQuotaError) {
                console.warn(`API key #${localIndex + 1} failed. Trying next key.`);
                // Move to the next key, wrap around if needed
                localIndex = (localIndex + 1) % apiKeys.length;
                continue;
            } else {
                // Not a quota error, fail fast
                throw e;
            }
        }
    }
    
    // If we've looped through all keys and they all failed
    setCurrentIndex(localIndex); // Update to the last attempted index
    throw new Error(`All ${apiKeys.length} API key(s) seem to be invalid or have exhausted their quota. Last error: ${lastError?.message}`);
  }, [apiKeys, currentIndex]);


  return {
    apiKeys,
    currentApiKey,
    currentIndex,
    addApiKey,
    removeApiKey,
    setCurrentIndex,
    executeWithRetry,
  };
};
