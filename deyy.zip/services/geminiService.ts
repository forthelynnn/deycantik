import { GoogleGenAI, Modality, Part } from "@google/genai";
import { UGCFormState, ImageFile, ProductViewMode } from "../types";
import { CUSTOM_VIBE_OPTION } from "../constants";

export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => {
      const result = reader.result as string;
      // remove "data:mime/type;base64," prefix
      resolve(result.split(',')[1]);
    };
    reader.onerror = (error) => reject(error);
  });
};

const generatePrompt = (state: UGCFormState, view: 'front' | 'back', modelImageProvided: boolean, iteration?: number): string => {
    const vibeDescription = (state.vibe === CUSTOM_VIBE_OPTION && state.customVibe) ? state.customVibe : state.vibe;
    
    let prompt = `Generate a photorealistic UGC TikTok-style fashion image.

Model: ${state.modelGender}, ethnicity ${state.ethnicity}, with ${state.hairColor} ${state.hairStyle} hair. Ensure realistic skin texture and natural human anatomy.
Pose Style: ${state.poseStyle}
Composition: ${state.composition}
Lighting: ${state.lighting}
Color Grading: ${state.colorGrading}
Vibe / Background: ${vibeDescription}

Aspect Ratio: ${state.aspectRatio}
Quality: ultra realistic, 4K, clean shadows, no distortion.`;

    if (iteration) {
      prompt += `\n\nStyle variation: ${iteration}. Create a unique composition and pose based on the prompt.`;
    }

    if (state.includeModel) {
        if (modelImageProvided) {
            prompt += "\n\nUse the uploaded model as the base identity. Maintain face and body. Blend product naturally with accurate lighting.";
        } else {
            prompt += "\n\nGenerate a new realistic model based on the selected attributes.";
        }
    }

    if (state.productViewMode === ProductViewMode.FrontOnly) {
        prompt += "\n\nRender the product from its FRONT VIEW only.";
    } else {
        if (view === 'front') {
            prompt += "\n\nUse the product FRONT VIEW image.";
        } else {
            prompt += "\n\nUse the product BACK VIEW image.";
        }
    }
    
    return prompt;
};


export const generateUGC = async (
    apiKey: string,
    formState: UGCFormState,
    productFront: ImageFile,
    productBack?: ImageFile,
    modelImage?: ImageFile
) => {
    if (!apiKey) {
        throw new Error("API Key is not configured.");
    }
    
    const ai = new GoogleGenAI({ apiKey });

    const generateSingleImage = async (view: 'front' | 'back', iteration?: number) => {
        const prompt = generatePrompt(formState, view, !!(formState.includeModel && modelImage), iteration);
        const imageParts: Part[] = [];

        const imageFile = view === 'front' ? productFront : productBack;
        if (!imageFile) {
            throw new Error(`Required product image for ${view} view is missing.`);
        }
        
        const base64Product = await fileToBase64(imageFile.file);
        imageParts.push({ inlineData: { mimeType: imageFile.file.type, data: base64Product } });
        
        if (formState.includeModel && modelImage) {
            const base64Model = await fileToBase64(modelImage.file);
            imageParts.push({ inlineData: { mimeType: modelImage.file.type, data: base64Model } });
        }
        
        const textPart: Part = { text: prompt };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [...imageParts, textPart] },
            config: {
                responseModalities: [Modality.IMAGE],
            },
        });

        const firstPart = response.candidates?.[0]?.content?.parts?.[0];
        if (firstPart && firstPart.inlineData) {
            const base64ImageBytes: string = firstPart.inlineData.data;
            return `data:${firstPart.inlineData.mimeType};base64,${base64ImageBytes}`;
        } else {
             const errorText = response?.candidates?.[0]?.finishReason;
             if (errorText) {
                throw new Error(`Image generation failed: ${errorText}. Please check your prompt and images.`);
             }
             throw new Error("Image generation failed. No image data in response.");
        }
    };

    if (formState.productViewMode === ProductViewMode.FrontAndBack) {
        const countPerSide = formState.imageCount / 2;
        const frontPromises = Array.from({ length: countPerSide }).map((_, index) => generateSingleImage('front', index + 1));
        const backPromises = Array.from({ length: countPerSide }).map((_, index) => generateSingleImage('back', index + 1));

        const frontImages = await Promise.all(frontPromises);
        const backImages = await Promise.all(backPromises);

        return [...frontImages, ...backImages];
    } else {
        const promises = Array.from({ length: formState.imageCount }).map((_, index) => generateSingleImage('front', index + 1));
        return Promise.all(promises);
    }
};
