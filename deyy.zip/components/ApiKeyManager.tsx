import React, { useState } from 'react';
import { ApiKey } from '../types';
import Button from './ui/Button';
import Card from './ui/Card';

interface ApiKeyManagerProps {
  apiKeys: ApiKey[];
  currentIndex: number;
  addApiKey: (key: string) => void;
  removeApiKey: (id: string) => void;
  setCurrentIndex: (index: number) => void;
}

const ApiKeyManager: React.FC<ApiKeyManagerProps> = ({ apiKeys, currentIndex, addApiKey, removeApiKey, setCurrentIndex }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [newKey, setNewKey] = useState('');

  const handleAddKey = () => {
    if (!newKey.trim()) return;
    addApiKey(newKey);
    setNewKey('');
  };

  const maskKey = (key: string) => `****${key.slice(-4)}`;

  return (
    <>
      <Button variant="secondary" onClick={() => setIsOpen(true)}>
        Manage API Keys
      </Button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-80 flex items-center justify-center z-50" onClick={() => setIsOpen(false)}>
          <Card className="p-6 max-w-lg w-full" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold text-white">API Key Management</h2>
              <button onClick={() => setIsOpen(false)} className="text-gray-400 hover:text-white text-2xl font-bold">&times;</button>
            </div>
            
            <div className="space-y-2 mb-6 max-h-60 overflow-y-auto pr-2">
              {apiKeys.map((apiKey, index) => (
                <div key={apiKey.id} className="flex items-center justify-between p-3 bg-[#1C1C1C] rounded-md">
                  <div className="flex items-center gap-4">
                    <input
                      type="radio"
                      name="api-key"
                      checked={index === currentIndex}
                      onChange={() => setCurrentIndex(index)}
                      className="form-radio h-4 w-4 text-yellow-400 bg-gray-700 border-gray-600 focus:ring-yellow-500"
                      aria-label={`Set API Key #${index + 1} as active`}
                    />
                    <span className="font-mono text-sm text-gray-300">
                      API Key #{index + 1}: {maskKey(apiKey.key)}
                      {index === currentIndex && <span className="text-yellow-400 text-xs ml-2">(aktif)</span>}
                    </span>
                  </div>
                  <button
                    onClick={() => removeApiKey(apiKey.id)}
                    className="text-red-500 hover:text-red-400 text-sm font-semibold"
                    aria-label={`Delete API Key #${index + 1}`}
                  >
                    Delete
                  </button>
                </div>
              ))}
               {apiKeys.length === 0 && <p className="text-gray-500 text-center py-4">No API keys found.</p>}
            </div>

            <div className="space-y-2 pt-4 border-t border-[#333]">
              <label htmlFor="new-key" className="text-sm font-medium text-gray-300">Add New API Key</label>
              <div className="flex gap-2">
                <input
                  id="new-key"
                  type="password"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="Enter a new Gemini API Key"
                  className="flex-grow px-3 py-2 bg-[#1C1C1C] border border-[#444] rounded-md text-white focus:ring-[#FFC400] focus:border-[#FFC400]"
                />
                <Button onClick={handleAddKey}>Add</Button>
              </div>
            </div>
          </Card>
        </div>
      )}
    </>
  );
};

export default ApiKeyManager;
