import React from 'react';
import Card from './ui/Card';
import { ProductViewMode } from '../types';

interface ImageGridProps {
  images: string[];
  isLoading: boolean;
  error: string | null;
  imageCount: number;
  productViewMode: ProductViewMode;
}

const ImageGrid: React.FC<ImageGridProps> = ({ images, isLoading, error, imageCount, productViewMode }) => {
  const SKELETON_COUNT = imageCount;

  const handleDownload = (src: string, index: number) => {
    const link = document.createElement('a');
    link.href = src;
    link.download = `ugc-outfit-${index + 1}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getLabel = (index: number): string => {
    if (productViewMode === ProductViewMode.FrontAndBack) {
        const countPerSide = images.length / 2;
        if (index < countPerSide) {
            return countPerSide > 1 ? `Front View #${index + 1}` : 'Front View';
        } else {
            const backIndex = index - countPerSide + 1;
            return countPerSide > 1 ? `Back View #${backIndex}` : 'Back View';
        }
    }
    return `Image #${index + 1}`;
  };

  return (
    <Card className="p-6 min-h-full">
      <h2 className="text-xl font-bold text-white mb-4">Generated Images</h2>
      {error && <div className="bg-red-900 border border-red-700 text-red-200 px-4 py-3 rounded-md mb-4" role="alert">{error}</div>}
      
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {isLoading && Array.from({ length: SKELETON_COUNT }).map((_, index) => (
          <div key={index} className="aspect-[9/16] bg-[#1C1C1C] rounded-lg animate-pulse"></div>
        ))}

        {!isLoading && images.map((src, index) => (
          <div key={index} className="relative group">
             <div className="absolute top-2 left-2 bg-black bg-opacity-60 text-white text-xs font-bold px-2 py-1 rounded z-10">
                {getLabel(index)}
              </div>
            <div className="aspect-[9/16] bg-[#1C1C1C] rounded-lg overflow-hidden shadow-lg">
              <img src={src} alt={`Generated UGC ${index + 1}`} className="w-full h-full object-cover" />
            </div>
            <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
               <button
                  onClick={() => handleDownload(src, index)}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-semibold text-black bg-[#FFC400] rounded-md hover:bg-yellow-300"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Download
                </button>
            </div>
          </div>
        ))}
        
        {!isLoading && images.length === 0 && (
            <div className="col-span-full h-96 flex flex-col items-center justify-center text-gray-500 border-2 border-dashed border-[#444] rounded-lg p-4 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p>Your generated images will appear here.</p>
                <p className="text-sm">Configure your settings and click "Generate UGC".</p>
            </div>
        )}
      </div>
    </Card>
  );
};

export default ImageGrid;