import React, { useState } from 'react';
import { ApiKey } from '../types';
import Card from './ui/Card';
import Button from './ui/Button';

interface ApiKeyGateProps {
  children: React.ReactNode;
  apiKeys: ApiKey[];
  addApiKey: (key: string) => void;
}

const ApiKeyGate: React.FC<ApiKeyGateProps> = ({ children, apiKeys, addApiKey }) => {
  const [newKey, setNewKey] = useState('');
  const [error, setError] = useState('');

  const handleAddKey = () => {
    if (!newKey.trim()) {
      setError('API Key cannot be empty.');
      return;
    }
    addApiKey(newKey);
    setNewKey('');
    setError('');
  };

  if (apiKeys.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-90 flex items-center justify-center z-50 p-4">
        <Card className="p-8 max-w-md w-full">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-white mb-2">Welcome!</h2>
            <p className="text-gray-400 mb-6">Belum ada API key. Silakan masukkan API key pertama.</p>
            <div className="space-y-4">
              <input
                type="password"
                value={newKey}
                onChange={(e) => setNewKey(e.target.value)}
                placeholder="Enter your Gemini API Key"
                className="w-full px-4 py-2 bg-[#1C1C1C] border border-[#444] rounded-md text-white focus:ring-[#FFC400] focus:border-[#FFC400]"
                aria-label="New API Key Input"
              />
              {error && <p className="text-red-500 text-sm">{error}</p>}
              <Button onClick={handleAddKey} className="w-full">
                Save and Start
              </Button>
               <p className="text-xs text-gray-500 mt-4">
                 Your API key is stored only in your browser's local storage and is never sent to our servers.
               </p>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return <>{children}</>;
};

export default ApiKeyGate;
