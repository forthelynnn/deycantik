

import React from 'react';
import { UGCFormState, ImageFile, ProductViewMode, AspectRatio, SpeechLanguage } from '../types';
import { ATTRIBUTE_OPTIONS, IMAGE_COUNT_OPTIONS, EVEN_IMAGE_COUNT_OPTIONS, CUSTOM_VIBE_OPTION } from '../constants';
import Card from './ui/Card';
import Button from './ui/Button';
import FileUpload from './ui/FileUpload';
import SegmentedControl from './ui/SegmentedControl';
import Select from './ui/Select';
import ToggleSwitch from './ui/ToggleSwitch';

interface GeneratorFormProps {
  formState: UGCFormState;
  setFormState: React.Dispatch<React.SetStateAction<UGCFormState>>;
  productFront: ImageFile | null;
  setProductFront: (file: ImageFile | null) => void;
  productBack: ImageFile | null;
  setProductBack: (file: ImageFile | null) => void;
  modelImage: ImageFile | null;
  setModelImage: (file: ImageFile | null) => void;
  onGenerate: () => void;
  isLoading: boolean;
  hasApiKey: boolean;
}

const GeneratorForm: React.FC<GeneratorFormProps> = ({
  formState, setFormState,
  productFront, setProductFront,
  productBack, setProductBack,
  modelImage, setModelImage,
  onGenerate, isLoading, hasApiKey
}) => {
  const handleFormChange = <K extends keyof UGCFormState>(key: K, value: UGCFormState[K]) => {
    setFormState(prev => ({ ...prev, [key]: value }));
  };
  
  const isBackRequired = formState.productViewMode === ProductViewMode.FrontAndBack;
  const isGenerateDisabled = isLoading || !productFront || (isBackRequired && !productBack) || !hasApiKey;

  React.useEffect(() => {
    if (formState.productViewMode === ProductViewMode.FrontAndBack && !EVEN_IMAGE_COUNT_OPTIONS.includes(formState.imageCount)) {
      handleFormChange('imageCount', 2);
    }
  }, [formState.productViewMode]);

  const imageCountOptions = isBackRequired ? EVEN_IMAGE_COUNT_OPTIONS : IMAGE_COUNT_OPTIONS;
  
  const { vibe, ...otherAttributes } = ATTRIBUTE_OPTIONS;

  return (
    <Card className="p-6">
        <div className="space-y-6">
            <ToggleSwitch
                label="Include Model"
                enabled={formState.includeModel}
                setEnabled={(value) => handleFormChange('includeModel', value)}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <FileUpload 
                    id="product-front" 
                    label="Upload Product Image — Front" 
                    required 
                    imageFile={productFront} 
                    setImageFile={setProductFront} 
                />
                <FileUpload 
                    id="product-back" 
                    label="Upload Product Image — Back" 
                    required={isBackRequired} 
                    imageFile={productBack} 
                    setImageFile={setProductBack} 
                />
                <FileUpload 
                    id="model-image" 
                    label="Upload Model Image" 
                    imageFile={modelImage} 
                    setImageFile={setModelImage} 
                />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <SegmentedControl
                    label="Product View Mode"
                    options={[ProductViewMode.FrontOnly, ProductViewMode.FrontAndBack]}
                    value={formState.productViewMode}
                    onChange={(value) => handleFormChange('productViewMode', value)}
                />
                <SegmentedControl
                    label="Aspect Ratio"
                    options={[AspectRatio.Portrait, AspectRatio.Landscape]}
                    value={formState.aspectRatio}
                    onChange={(value) => handleFormChange('aspectRatio', value)}
                />
            </div>
            
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <SegmentedControl
                        label="Image Count"
                        options={imageCountOptions}
                        value={formState.imageCount}
                        onChange={(value) => handleFormChange('imageCount', value)}
                    />
                </div>
                <Select
                    label="Speech Language"
                    options={[SpeechLanguage.Indonesia, SpeechLanguage.English, SpeechLanguage.Malaysia]}
                    value={formState.speechLanguage}
                    onChange={(e) => handleFormChange('speechLanguage', e.target.value as SpeechLanguage)}
                />
            </div>
            
            <h3 className="text-lg font-semibold text-white pt-4 border-t border-[#333]">Model & Scene Attributes</h3>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {Object.entries(otherAttributes).map(([key, options]) => (
                    <Select
                        key={key}
                        label={key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())}
                        options={options}
                        value={formState[key as keyof typeof otherAttributes]}
                        onChange={(e) => handleFormChange(key as keyof UGCFormState, e.target.value)}
                    />
                ))}

                <Select
                    label="Vibe"
                    options={vibe}
                    value={formState.vibe}
                    onChange={(e) => handleFormChange('vibe', e.target.value)}
                />
                
                {formState.vibe === CUSTOM_VIBE_OPTION && (
                    <div>
                        <label htmlFor="custom-vibe-input" className="block text-sm font-medium text-gray-300 mb-1">
                            Custom Vibe
                        </label>
                        <input
                            id="custom-vibe-input"
                            type="text"
                            value={formState.customVibe || ''}
                            onChange={(e) => handleFormChange('customVibe', e.target.value)}
                            placeholder="e.g., 90s retro diner"
                            className="mt-1 block w-full pl-3 pr-3 py-2 text-base bg-[#1C1C1C] border-[#444] focus:outline-none focus:ring-[#FFC400] focus:border-[#FFC400] sm:text-sm rounded-md text-white"
                        />
                    </div>
                )}
            </div>

            <div className="pt-6 border-t border-[#333]">
                <Button onClick={onGenerate} isLoading={isLoading} disabled={isGenerateDisabled} className="w-full">
                    {hasApiKey ? 'Generate UGC' : 'Add API Key to Generate'}
                </Button>
            </div>
        </div>
    </Card>
  );
};

export default GeneratorForm;
