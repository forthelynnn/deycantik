import React from 'react';

interface SelectProps extends React.SelectHTMLAttributes<HTMLSelectElement> {
  label: string;
  options: readonly string[];
}

const Select: React.FC<SelectProps> = ({ label, options, ...props }) => {
  return (
    <div>
      <label htmlFor={props.id || label} className="block text-sm font-medium text-gray-300 mb-1">
        {label}
      </label>
      <select
        id={props.id || label}
        {...props}
        className="mt-1 block w-full pl-3 pr-10 py-2 text-base bg-[#1C1C1C] border-[#444] focus:outline-none focus:ring-[#FFC400] focus:border-[#FFC400] sm:text-sm rounded-md text-white"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {option}
          </option>
        ))}
      </select>
    </div>
  );
};

export default Select;
