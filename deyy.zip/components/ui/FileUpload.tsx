import React, { useRef } from 'react';
import { ImageFile } from '../../types';

interface FileUploadProps {
  id: string;
  label: string;
  required?: boolean;
  imageFile: ImageFile | null;
  setImageFile: (file: ImageFile | null) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ id, label, required, imageFile, setImageFile }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      if (file.size > 10 * 1024 * 1024) { // 10MB limit
        alert("File is too large. Maximum size is 10MB.");
        return;
      }
      setImageFile({
        file,
        preview: URL.createObjectURL(file),
      });
    }
  };

  const handleRemoveImage = () => {
    setImageFile(null);
    if(fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-gray-300 mb-1">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      <div
        className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-[#444] border-dashed rounded-md hover:border-[#FFC400] transition-colors"
      >
        <div className="space-y-1 text-center w-full">
          {imageFile ? (
            <div className="relative group w-full">
              <img src={imageFile.preview} alt="Preview" className="mx-auto h-32 w-auto rounded-md object-contain" />
              <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <button
                  type="button"
                  onClick={handleRemoveImage}
                  className="px-3 py-1 text-xs font-semibold text-white bg-red-600 rounded-md hover:bg-red-500"
                >
                  Remove
                </button>
              </div>
            </div>
          ) : (
            <>
              <svg className="mx-auto h-12 w-12 text-gray-500" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
                <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div className="flex text-sm text-gray-500 justify-center">
                <label
                  htmlFor={id}
                  className="relative cursor-pointer bg-transparent rounded-md font-medium text-[#FFC400] hover:text-yellow-300 focus-within:outline-none"
                >
                  <span>Upload Image</span>
                  <input id={id} name={id} type="file" className="sr-only" onChange={handleFileChange} accept="image/*" ref={fileInputRef} />
                </label>
              </div>
              <p className="text-xs text-gray-500">PNG, JPG up to 10MB</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default FileUpload;
