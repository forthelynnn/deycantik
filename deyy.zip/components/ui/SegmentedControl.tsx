import React from 'react';

interface SegmentedControlProps<T extends string | number> {
  label: string;
  options: readonly T[];
  value: T;
  onChange: (value: T) => void;
}

const SegmentedControl = <T extends string | number>({ label, options, value, onChange }: SegmentedControlProps<T>) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-300 mb-1">{label}</label>
      <div className="flex bg-[#1C1C1C] rounded-lg p-1 space-x-1 border border-[#444]">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            className={`w-full py-2 text-sm font-medium rounded-md transition-colors focus:outline-none ${
              value === option
                ? 'bg-[#FFC400] text-black shadow'
                : 'text-gray-300 hover:bg-[#333]'
            }`}
          >
            {option}
          </button>
        ))}
      </div>
    </div>
  );
};

export default SegmentedControl;
