import { UGCFormState, ProductViewMode, AspectRatio, SpeechLanguage } from './types';

export const CUSTOM_VIBE_OPTION = "Custom...";

export const ATTRIBUTE_OPTIONS = {
  modelGender: ["Female", "Male", "Androgynous", "Unspecified"],
  hairStyle: ["Long Straight", "Long Wavy", "Long Curly", "Medium Bob", "Short Bob", "Pixie Cut", "Ponytail", "Bun", "Braided"],
  hairColor: ["Black", "Dark Brown", "Light Brown", "Blonde", "Platinum", "Red", "Ginger", "Ash Grey"],
  ethnicity: ["Indonesian", "Asian", "Caucasian", "African", "Middle Eastern", "Latin", "Indian", "Mixed"],
  poseStyle: ["Eye Contact", "Natural Smile", "Side Look", "Walking", "Sitting Casual", "Standing Straight", "Holding Product", "Talking Style", "Over-the-Shoulder", "Leaning Pose", "Looking Down", "Action / Movement"],
  composition: ["Vlog Style", "Product Focus", "Full Body", "Half Body", "Close Up", "Lifestyle Shot", "Fashion Editorial", "POV Shot", "Mirror Selfie Style", "Minimalist Studio Shot"],
  lighting: ["Ring Light", "Soft Light", "Golden Hour", "Natural Window Light", "Studio Light", "High Contrast", "Low Light Mood", "Neon Light", "Outdoor Shade"],
  colorGrading: ["Natural", "Warm", "Cool", "Cinematic", "High Contrast", "Soft Pastel", "Moody", "Vibrant"],
  vibe: ["Bedroom Morning", "Cafe Aesthetic", "Outdoor Street", "Minimalist Studio", "Luxury Living Room", "Shopping Mall", "Rooftop Sunset", "Beach Daylight", "Gym & Fitness", "Office Modern", "Cozy Warm Room", "Clean White Background", "Fashion Runway Style", CUSTOM_VIBE_OPTION],
};

export const IMAGE_COUNT_OPTIONS = [1, 2, 3, 4, 5, 6];
export const EVEN_IMAGE_COUNT_OPTIONS = [2, 4, 6];


export const DEFAULT_FORM_STATE: UGCFormState = {
  includeModel: true,
  productViewMode: ProductViewMode.FrontOnly,
  aspectRatio: AspectRatio.Portrait,
  imageCount: 2,
  speechLanguage: SpeechLanguage.Indonesia,
  modelGender: ATTRIBUTE_OPTIONS.modelGender[0],
  hairStyle: ATTRIBUTE_OPTIONS.hairStyle[0],
  hairColor: ATTRIBUTE_OPTIONS.hairColor[0],
  ethnicity: ATTRIBUTE_OPTIONS.ethnicity[0],
  poseStyle: ATTRIBUTE_OPTIONS.poseStyle[0],
  composition: ATTRIBUTE_OPTIONS.composition[0],
  lighting: ATTRIBUTE_OPTIONS.lighting[0],
  colorGrading: ATTRIBUTE_OPTIONS.colorGrading[0],
  vibe: ATTRIBUTE_OPTIONS.vibe[0],
  customVibe: '',
};
