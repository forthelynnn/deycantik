export enum ProductViewMode {
  FrontOnly = "Front Only",
  FrontAndBack = "Front & Back",
}

export enum AspectRatio {
  Portrait = "9:16",
  Landscape = "16:9",
}

export enum SpeechLanguage {
  Indonesia = "Indonesia",
  English = "English",
  Malaysia = "Malaysia",
}

export interface ApiKey {
  id: string;
  key: string;
}

export interface UGCFormState {
  includeModel: boolean;
  productViewMode: ProductViewMode;
  aspectRatio: AspectRatio;
  imageCount: number;
  speechLanguage: SpeechLanguage;
  modelGender: string;
  hairStyle: string;
  hairColor: string;
  ethnicity: string;
  poseStyle: string;
  composition: string;
  lighting: string;
  colorGrading: string;
  vibe: string;
  customVibe?: string;
}

export interface ImageFile {
  file: File;
  preview: string;
}
