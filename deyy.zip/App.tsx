
import React, { useState, useCallback } from 'react';
import { UGCFormState, ImageFile, ProductViewMode } from './types';
import { DEFAULT_FORM_STATE } from './constants';
import { generateUGC } from './services/geminiService';
import { useApiKeyManager } from './hooks/useApiKeyManager';

import GeneratorForm from './components/GeneratorForm';
import ImageGrid from './components/ImageGrid';
import ApiKeyGate from './components/ApiKeyGate';
import ApiKeyManager from './components/ApiKeyManager';

function App() {
  const [formState, setFormState] = useState<UGCFormState>(DEFAULT_FORM_STATE);
  const [productFront, setProductFront] = useState<ImageFile | null>(null);
  const [productBack, setProductBack] = useState<ImageFile | null>(null);
  const [modelImage, setModelImage] = useState<ImageFile | null>(null);

  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    apiKeys,
    currentIndex,
    addApiKey,
    removeApiKey,
    setCurrentIndex,
    executeWithRetry
  } = useApiKeyManager();

  const handleGenerate = useCallback(async () => {
    setError(null);
    setGeneratedImages([]);

    if (!productFront) {
      setError("Product Image (Front) is required.");
      return;
    }
    if (formState.productViewMode === ProductViewMode.FrontAndBack && !productBack) {
      setError("Product Image (Back) is required for Front & Back mode.");
      return;
    }
    if (apiKeys.length === 0) {
      setError("Please add an API key before generating images.");
      return;
    }

    setIsLoading(true);

    try {
        const generationTask = (key: string) => generateUGC(key, formState, productFront, productBack, modelImage);
        const images = await executeWithRetry(generationTask);
        setGeneratedImages(images);
    } catch (e: any) {
        console.error(e);
        setError(e.message || "An unknown error occurred during generation.");
    } finally {
        setIsLoading(false);
    }
  }, [formState, productFront, productBack, modelImage, apiKeys, executeWithRetry]);

  return (
    <ApiKeyGate apiKeys={apiKeys} addApiKey={addApiKey}>
      <div className="min-h-screen p-4 md:p-8">
        <div className="max-w-7xl mx-auto space-y-8">
          <header className="flex flex-wrap justify-between items-center gap-4">
              <div>
                  <h1 className="text-2xl md:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-200 to-yellow-500">
                      UGC Outfit Generator
                  </h1>
                  <p className="mt-1 text-gray-400">AI-Powered Fashion Content Creation</p>
              </div>
              <ApiKeyManager 
                  apiKeys={apiKeys}
                  currentIndex={currentIndex}
                  addApiKey={addApiKey}
                  removeApiKey={removeApiKey}
                  setCurrentIndex={setCurrentIndex}
              />
          </header>

          <main className="space-y-8">
            <GeneratorForm 
              formState={formState}
              setFormState={setFormState}
              productFront={productFront}
              setProductFront={setProductFront}
              productBack={productBack}
              setProductBack={setProductBack}
              modelImage={modelImage}
              setModelImage={setModelImage}
              onGenerate={handleGenerate}
              isLoading={isLoading}
              hasApiKey={apiKeys.length > 0}
            />
            <ImageGrid 
              images={generatedImages}
              isLoading={isLoading}
              error={error}
              imageCount={formState.imageCount}
              productViewMode={formState.productViewMode}
            />
          </main>
        </div>
      </div>
    </ApiKeyGate>
  );
}

export default App;
